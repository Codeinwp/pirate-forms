<?php
/**
 * Sample class for PHPUnit.
 *
 * @package     nivo-slider
 * @subpackage  Tests
 * @copyright   Copyright (c) 2017, Marius Cristea
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       3.0.0
 */

/**
 * Sample test class.
 */
class Test_Pirate_Forms extends WP_UnitTestCase {

	public function test_generic() {
		$this->assertTrue(true);
	}

}
